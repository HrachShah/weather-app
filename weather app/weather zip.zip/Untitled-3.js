// API Key
const API_KEY = 'zpka_9b4b87c3f6524a8796512be6d5c6de77_9bea3791';

// Three.js variables
let scene, camera, renderer, sphere;

// Leaflet map
let map;

// Initialize app
document.addEventListener('DOMContentLoaded', () => {
    initThreeJS();
    initMap();
    // Default city
    fetchWeather('London');
});

// Initialize Three.js
function initThreeJS() {
    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    renderer = new THREE.WebGLRenderer({ canvas: document.getElementById('threejs-canvas'), alpha: true });
    renderer.setSize(window.innerWidth, window.innerHeight);

    // Create glass sphere
    const geometry = new THREE.SphereGeometry(1, 64, 64);
    const material = new THREE.MeshPhysicalMaterial({
        transmission: 1,
        opacity: 0.5,
        metalness: 0,
        roughness: 0,
        ior: 1.45,
        thickness: 0.1,
        envMapIntensity: 1,
        clearcoat: 1,
        clearcoatRoughness: 0,
        transmission: 1,
        side: THREE.DoubleSide
    });
    sphere = new THREE.Mesh(geometry, material);
    scene.add(sphere);

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
    scene.add(ambientLight);
    const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
    directionalLight.position.set(5, 5, 5);
    scene.add(directionalLight);

    camera.position.z = 3;

    animate();
}

function animate() {
    requestAnimationFrame(animate);
    sphere.rotation.y += 0.01;
    renderer.render(scene, camera);
}

// Initialize Leaflet map
function initMap() {
    map = L.map('map').setView([51.505, -0.09], 13);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);
}

// Fetch weather data
async function fetchWeather(city) {
    try {
        const response = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}&units=metric`);
        const data = await response.json();
        if (data.cod === 200) {
            updateUI(data);
            updateMap(data.coord.lat, data.coord.lon);
            updateSphere(data.main.temp);
        } else {
            alert('City not found');
        }
    } catch (error) {
        console.error('Error fetching weather:', error);
    }
}

// Update UI
function updateUI(data) {
    document.getElementById('city-name').textContent = data.name;
    document.getElementById('temperature').textContent = `${Math.round(data.main.temp)}°C`;
    document.getElementById('description').textContent = data.weather[0].description;
    document.getElementById('humidity').textContent = `Humidity: ${data.main.humidity}%`;
    document.getElementById('wind').textContent = `Wind: ${data.wind.speed} m/s`;
}

// Update map
function updateMap(lat, lon) {
    map.setView([lat, lon], 13);
    L.marker([lat, lon]).addTo(map);
}

// Update sphere based on temperature
function updateSphere(temp) {
    // Change color based on temp
    let color;
    if (temp < 0) color = 0x87CEEB; // Cold blue
    else if (temp < 20) color = 0xFFD700; // Warm yellow
    else color = 0xFF4500; // Hot red
    sphere.material.color.setHex(color);
}

// Event listeners
document.getElementById('search-btn').addEventListener('click', () => {
    const city = document.getElementById('city-input').value;
    if (city) fetchWeather(city);
});

document.getElementById('city-input').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        const city = e.target.value;
        if (city) fetchWeather(city);
    }
});

// Resize
window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
});
